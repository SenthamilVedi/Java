// Create a request variable and assign a new XMLHttpRequest object to it.
var request = new XMLHttpRequest()
// Open a new connection, using the GET request on the URL endpoint
request.open('GET', 'http://localhost:8080/movies', true)

request.onload = function () {
  // Begin accessing JSON data here
	var data = JSON.parse(this.response)
	 if (request.status >= 200 && request.status < 400) {
		 if(data=="")
		 {
			 const h3 = document.createElement('h3')
			 const brek = document.createElement('br')
			 h3.textContent = "No Movie to display"
			 const app = document.getElementById('root')
			 app.appendChild(brek)
			 app.appendChild(h3)
		 }
		 else
		 {
			 data.forEach(movie => {
				 const h3 = document.createElement('h3')
				 const brek = document.createElement('br')
				 h3.textContent = "Movie Title: " + movie.title
				 const app = document.getElementById('root')
				 app.appendChild(brek)
				 app.appendChild(h3)
				 const h4 = document.createElement('h4')
				 h4.textContent = "Director: " + movie.director
				 app.appendChild(h4)
			 })
		}
	 }
  }
// Send request
request.send()


