// Create a request variable and assign a new XMLHttpRequest object to it.
var request = new XMLHttpRequest()

// Open a new connection, using the POST request on the URL endpoint
request.open('POST', 'http://localhost:8080/movie', true)

request.onload = function () {
	
	if (request.status >= 200 && request.status < 400) {
			const h1 = document.createElement('h1')
			const brek = document.createElement('br')
			h1.textContent = "Success!!"
			const app = document.getElementById('root')
			app.appendChild(brek)
			app.appendChild(brek)
			app.appendChild(brek)
			app.appendChild(h1)
	}
	
	else{
		const h1 = document.createElement('h1')
		const brek = document.createElement('br')
		h1.textContent = "Problem in adding movies!"
		const app = document.getElementById('root')
		app.appendChild(brek)
		app.appendChild(brek)
		app.appendChild(brek)
		app.appendChild(h1)
	}
  
  }
// Send request
request.send()
