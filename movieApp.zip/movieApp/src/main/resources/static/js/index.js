
 function redirectAdmin() {
	  window.location.replace("/add");
	}
  
  function redirectMovies() {
	  window.location.replace("/display");
	}