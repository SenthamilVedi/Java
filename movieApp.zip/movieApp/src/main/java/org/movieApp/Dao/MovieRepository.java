package org.movieApp.Dao;

import org.springframework.data.repository.CrudRepository;
import org.movieApp.Entity.MovieEntity;

public interface MovieRepository extends CrudRepository<MovieEntity, Integer>{

}
