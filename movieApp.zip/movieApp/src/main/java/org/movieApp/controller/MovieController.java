package org.movieApp.controller;

import java.util.Optional;

import javax.validation.Valid;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import org.movieApp.Entity.MovieEntity;
import org.movieApp.Dao.MovieRepository;

@RestController
public class MovieController {
	
	@Autowired
	MovieRepository movieRepository;
     
     
    @PostMapping(value="/movie")
    public MovieEntity createMovie() {
        //movieRepository.save(movie);
    	MovieEntity movie = new MovieEntity(1,"ET","Steven Spielberg");
    	movieRepository.save(movie);
        return movie;
    }
     
     
    @PutMapping(value="/movie")
    public MovieEntity updateMovie(@Valid @RequestBody MovieEntity movie) {
        movieRepository.save(movie);
        return movie;
    }
     
 
     
    @DeleteMapping(value="/movie")
    public MovieEntity deleteMovie(@Valid @RequestBody  MovieEntity movie) {
        movieRepository.delete(movie);
        return movie;
    }
     
     
 
    @GetMapping(value="/movie/{id}")
    public Optional<MovieEntity> getMovie(@PathVariable Integer id) {
        return movieRepository.findById(id);
    }
     
 
     
    @GetMapping(value="/movies")
    public Iterable<MovieEntity> getAllMovie() {
        return movieRepository.findAll();
    }


}
