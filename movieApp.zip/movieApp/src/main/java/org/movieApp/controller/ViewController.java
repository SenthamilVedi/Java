package org.movieApp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ViewController {
	
	@RequestMapping("/add")
    public String add() {
        return "Add";
    }
	 
	@RequestMapping("/display")
	public String display() {
	    return "Display";
	}  
	
	@RequestMapping("/index")
	public String index() {
	    return "Index";
	} 

}
